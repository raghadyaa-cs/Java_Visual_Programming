import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;

/**
 * PitWall - F1 Dashboard Wireframe
 * Visual Programming Project
 * Run in NetBeans: Right-click -> Run File
 */
public class PitWallDashboard extends JFrame {

    // ── Color Palette ──────────────────────────────────────────
    static final Color BG_DARK    = new Color(15, 15, 20);
    static final Color BG_PANEL   = new Color(25, 25, 35);
    static final Color ACCENT_RED = new Color(225, 6, 0);
    static final Color TEXT_WHITE = new Color(230, 230, 240);
    static final Color TEXT_GREY  = new Color(110, 110, 140);
    static final Color BORDER_COL = new Color(40, 40, 60);
    static final Color GOLD       = new Color(255, 200, 0);
    static final Color GREEN      = new Color(0, 210, 90);

    public PitWallDashboard() {
        setTitle("PitWall — F1 Dashboard");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1200, 750);
        setLocationRelativeTo(null);
        getContentPane().setBackground(BG_DARK);
        setLayout(new BorderLayout(0, 0));

        add(buildTopBar(), BorderLayout.NORTH);

        JTabbedPane tabs = buildTabs();
        tabs.setBackground(BG_DARK);
        add(tabs, BorderLayout.CENTER);

        setVisible(true);
    }

    // ── TOP BAR ────────────────────────────────────────────────
    JPanel buildTopBar() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(new Color(10, 10, 15));
        bar.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_COL));
        bar.setPreferredSize(new Dimension(0, 52));

        // Logo
        JLabel logo = new JLabel("  ● PITWALL");
        logo.setFont(new Font("Monospaced", Font.BOLD, 18));
        logo.setForeground(TEXT_WHITE);
        bar.add(logo, BorderLayout.WEST);

        // Season label
        JLabel season = new JLabel("2025 Formula 1 Season   ");
        season.setFont(new Font("SansSerif", Font.PLAIN, 13));
        season.setForeground(TEXT_GREY);
        bar.add(season, BorderLayout.EAST);

        return bar;
    }

    // ── TABS ───────────────────────────────────────────────────
    JTabbedPane buildTabs() {
        JTabbedPane tabs = new JTabbedPane();
        tabs.setBackground(BG_DARK);
        tabs.setForeground(TEXT_WHITE);
        tabs.setFont(new Font("SansSerif", Font.BOLD, 13));

        tabs.addTab("🏠  Dashboard",    buildDashboard());
        tabs.addTab("🏆  Standings",    buildStandings());
        tabs.addTab("📅  Race Results", buildRaceResults());
        tabs.addTab("⏱  Lap Stats",    buildLapStats());
        tabs.addTab("📰  News",         buildNews());
        tabs.addTab("🎯  Trivia",       buildTrivia());

        return tabs;
    }

    // ══════════════════════════════════════════════════════════
    // TAB 1 — DASHBOARD
    // ══════════════════════════════════════════════════════════
    JPanel buildDashboard() {
        JPanel root = darkPanel(new GridLayout(1, 3, 12, 12));
        root.setBorder(new EmptyBorder(16, 16, 16, 16));

        // Left — Next Race
        JPanel nextRace = titledCard("NEXT RACE");
        nextRace.setLayout(new BoxLayout(nextRace, BoxLayout.Y_AXIS));
        nextRace.add(bigLabel("Saudi Arabian GP", 20, TEXT_WHITE));
        nextRace.add(smallLabel("Jeddah Corniche Circuit · Round 4"));
        nextRace.add(Box.createVerticalStrut(16));
        nextRace.add(bigLabel("03 : 14 : 22", 28, ACCENT_RED));
        nextRace.add(smallLabel("Days  :  Hours  :  Mins"));
        root.add(nextRace);

        // Center — Top 3
        JPanel top3 = titledCard("CURRENT LEADER");
        top3.setLayout(new BoxLayout(top3, BoxLayout.Y_AXIS));
        String[][] top3data = {
            {"1st", "M. Verstappen",  "77 pts"},
            {"2nd", "C. Leclerc",     "62 pts"},
            {"3rd", "L. Hamilton",    "55 pts"},
        };
        Color[] medals = {GOLD, new Color(192,192,192), new Color(205,127,50)};
        for (int i = 0; i < 3; i++) {
            JPanel row = new JPanel(new BorderLayout(10, 0));
            row.setOpaque(false);
            row.setBorder(new EmptyBorder(6, 0, 6, 0));
            JLabel pos = new JLabel(top3data[i][0]);
            pos.setFont(new Font("Monospaced", Font.BOLD, 14));
            pos.setForeground(medals[i]);
            JLabel name = new JLabel(top3data[i][1]);
            name.setFont(new Font("SansSerif", Font.PLAIN, 14));
            name.setForeground(TEXT_WHITE);
            JLabel pts = new JLabel(top3data[i][2]);
            pts.setFont(new Font("Monospaced", Font.BOLD, 14));
            pts.setForeground(GREEN);
            row.add(pos, BorderLayout.WEST);
            row.add(name, BorderLayout.CENTER);
            row.add(pts, BorderLayout.EAST);
            top3.add(row);
        }
        root.add(top3);

        // Right — Last Result
        JPanel lastResult = titledCard("LAST RACE — Bahrain GP");
        lastResult.setLayout(new BoxLayout(lastResult, BoxLayout.Y_AXIS));
        String[][] res = {
            {"P1", "Verstappen", "1:31:44"},
            {"P2", "Leclerc",    "+4.9s"},
            {"P3", "Hamilton",   "+9.1s"},
            {"P4", "Norris",     "+11.2s"},
            {"P5", "Sainz",      "+16.4s"},
        };
        for (String[] r : res) {
            JPanel row = new JPanel(new BorderLayout(10, 0));
            row.setOpaque(false);
            row.setBorder(new EmptyBorder(5, 0, 5, 0));
            JLabel pos = new JLabel(r[0]);
            pos.setFont(new Font("Monospaced", Font.BOLD, 13));
            pos.setForeground(r[0].equals("P1") ? GOLD : TEXT_GREY);
            JLabel name = new JLabel(r[1]);
            name.setFont(new Font("SansSerif", Font.PLAIN, 13));
            name.setForeground(TEXT_WHITE);
            JLabel time = new JLabel(r[2]);
            time.setFont(new Font("Monospaced", Font.PLAIN, 12));
            time.setForeground(TEXT_GREY);
            row.add(pos, BorderLayout.WEST);
            row.add(name, BorderLayout.CENTER);
            row.add(time, BorderLayout.EAST);
            lastResult.add(row);
        }
        root.add(lastResult);

        return root;
    }

    // ══════════════════════════════════════════════════════════
    // TAB 2 — STANDINGS
    // ══════════════════════════════════════════════════════════
    JPanel buildStandings() {
        JPanel root = darkPanel(new GridLayout(1, 2, 12, 0));
        root.setBorder(new EmptyBorder(16, 16, 16, 16));

        // Driver Standings Table
        String[] dCols = {"Pos", "Driver", "Team", "Pts"};
        Object[][] dData = {
            {"1", "M. Verstappen", "Red Bull",    "77"},
            {"2", "C. Leclerc",    "Ferrari",     "62"},
            {"3", "L. Hamilton",   "Mercedes",    "55"},
            {"4", "L. Norris",     "McLaren",     "44"},
            {"5", "C. Sainz",      "Ferrari",     "38"},
            {"6", "S. Perez",      "Red Bull",    "31"},
            {"7", "G. Russell",    "Mercedes",    "24"},
            {"8", "F. Alonso",     "Aston Martin","18"},
        };
        root.add(wrapTable("DRIVER STANDINGS", dCols, dData));

        // Constructor Standings Table
        String[] cCols = {"Pos", "Constructor", "Pts"};
        Object[][] cData = {
            {"1", "Red Bull Racing", "108"},
            {"2", "Ferrari",         "100"},
            {"3", "Mercedes",        "79"},
            {"4", "McLaren",         "62"},
            {"5", "Aston Martin",    "33"},
            {"6", "Alpine",          "12"},
            {"7", "Williams",        "8"},
            {"8", "Haas",            "4"},
        };
        root.add(wrapTable("CONSTRUCTOR STANDINGS", cCols, cData));

        return root;
    }

    // ══════════════════════════════════════════════════════════
    // TAB 3 — RACE RESULTS
    // ══════════════════════════════════════════════════════════
    JPanel buildRaceResults() {
        JPanel root = darkPanel(new BorderLayout(12, 12));
        root.setBorder(new EmptyBorder(16, 16, 16, 16));

        // Race selector
        JPanel top = darkPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        JLabel lbl = new JLabel("Select Race: ");
        lbl.setForeground(TEXT_WHITE);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 13));
        String[] races = {"Round 1 — Bahrain GP", "Round 2 — Saudi Arabian GP", "Round 3 — Australian GP"};
        JComboBox<String> combo = new JComboBox<>(races);
        combo.setBackground(BG_PANEL);
        combo.setForeground(TEXT_WHITE);
        top.add(lbl);
        top.add(combo);
        root.add(top, BorderLayout.NORTH);

        // Results table
        String[] cols = {"Pos", "No.", "Driver", "Team", "Time / Gap", "Pts", "Fastest Lap"};
        Object[][] data = {
            {"1", "1",  "M. Verstappen", "Red Bull",  "1:31:44.742", "25", "1:31.447 🟣"},
            {"2", "16", "C. Leclerc",    "Ferrari",   "+4.982s",     "18", "1:31.892"},
            {"3", "44", "L. Hamilton",   "Mercedes",  "+9.140s",     "15", "1:32.110"},
            {"4", "4",  "L. Norris",     "McLaren",   "+11.220s",    "12", "1:32.384"},
            {"5", "55", "C. Sainz",      "Ferrari",   "+16.480s",    "10", "1:32.618"},
            {"6", "11", "S. Perez",      "Red Bull",  "+22.110s",    "8",  "1:32.900"},
            {"7", "63", "G. Russell",    "Mercedes",  "+28.340s",    "6",  "1:33.101"},
            {"8", "14", "F. Alonso",     "Aston M.",  "+35.220s",    "4",  "1:33.440"},
        };
        root.add(wrapTable("RACE RESULTS — BAHRAIN GRAND PRIX", cols, data), BorderLayout.CENTER);

        return root;
    }

    // ══════════════════════════════════════════════════════════
    // TAB 4 — LAP STATS
    // ══════════════════════════════════════════════════════════
    JPanel buildLapStats() {
        JPanel root = darkPanel(new GridLayout(1, 2, 12, 0));
        root.setBorder(new EmptyBorder(16, 16, 16, 16));

        // Fastest laps table
        String[] cols = {"Lap", "Driver", "Time", "Speed"};
        Object[][] data = {
            {"45", "Verstappen", "1:31.447", "231 km/h"},
            {"42", "Norris",     "1:31.892", "230 km/h"},
            {"44", "Leclerc",    "1:32.110", "229 km/h"},
            {"43", "Hamilton",   "1:32.384", "228 km/h"},
            {"40", "Russell",    "1:32.618", "227 km/h"},
            {"41", "Sainz",      "1:32.900", "226 km/h"},
        };
        root.add(wrapTable("FASTEST LAPS — BAHRAIN GP", cols, data));

        // Bar chart panel
        JPanel chartCard = titledCard("POINTS CHART — TOP DRIVERS");
        chartCard.setLayout(new BorderLayout());
        chartCard.add(new BarChartPanel(), BorderLayout.CENTER);
        root.add(chartCard);

        return root;
    }

    // ══════════════════════════════════════════════════════════
    // TAB 5 — NEWS
    // ══════════════════════════════════════════════════════════
    JPanel buildNews() {
        JPanel root = darkPanel(new BorderLayout(0, 12));
        root.setBorder(new EmptyBorder(16, 16, 16, 16));

        JLabel title = new JLabel("LATEST F1 NEWS");
        title.setFont(new Font("Monospaced", Font.BOLD, 14));
        title.setForeground(ACCENT_RED);
        title.setBorder(new EmptyBorder(0, 0, 10, 0));
        root.add(title, BorderLayout.NORTH);

        JPanel list = darkPanel(new GridLayout(0, 1, 0, 8));

        String[][] news = {
            {"[RACE]",  "Verstappen dominates Bahrain GP, extends championship lead",           "2 hrs ago · Formula1.com"},
            {"[TEAM]",  "Ferrari confirm upgrade package for Saudi Arabia race weekend",         "4 hrs ago · Autosport"},
            {"[TECH]",  "McLaren's new floor design under scrutiny after Bahrain data analysis", "6 hrs ago · The Race"},
            {"[RACE]",  "Hamilton praises Mercedes improvement despite P3 finish",              "8 hrs ago · Sky Sports"},
            {"[TEAM]",  "Alonso hints at 2026 driver market talks with Red Bull",               "10 hrs ago · GPFans"},
        };

        for (String[] item : news) {
            JPanel card = new JPanel(new BorderLayout(10, 4));
            card.setBackground(BG_PANEL);
            card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COL, 1),
                new EmptyBorder(10, 14, 10, 14)
            ));
            JLabel tag = new JLabel(item[0]);
            tag.setFont(new Font("Monospaced", Font.BOLD, 11));
            tag.setForeground(ACCENT_RED);
            JLabel headline = new JLabel(item[1]);
            headline.setFont(new Font("SansSerif", Font.BOLD, 13));
            headline.setForeground(TEXT_WHITE);
            JLabel meta = new JLabel(item[2]);
            meta.setFont(new Font("SansSerif", Font.PLAIN, 11));
            meta.setForeground(TEXT_GREY);
            card.add(tag, BorderLayout.WEST);
            card.add(headline, BorderLayout.CENTER);
            card.add(meta, BorderLayout.EAST);
            list.add(card);
        }

        JScrollPane scroll = new JScrollPane(list);
        scroll.getViewport().setBackground(BG_DARK);
        scroll.setBorder(null);
        root.add(scroll, BorderLayout.CENTER);
        return root;
    }

    // ══════════════════════════════════════════════════════════
    // TAB 6 — TRIVIA
    // ══════════════════════════════════════════════════════════
    JPanel buildTrivia() {
        JPanel root = darkPanel(new BorderLayout(0, 16));
        root.setBorder(new EmptyBorder(30, 60, 30, 60));

        // Score
        JLabel scoreLbl = new JLabel("Score: 0 / 10", SwingConstants.RIGHT);
        scoreLbl.setFont(new Font("Monospaced", Font.BOLD, 14));
        scoreLbl.setForeground(GOLD);
        root.add(scoreLbl, BorderLayout.NORTH);

        // Question card
        JPanel qCard = titledCard("QUESTION 1 OF 10");
        qCard.setLayout(new BoxLayout(qCard, BoxLayout.Y_AXIS));

        JLabel q = new JLabel("<html><div style='width:500px'>Which year did Max Verstappen become the youngest race winner in F1 history?</div></html>");
        q.setFont(new Font("SansSerif", Font.BOLD, 16));
        q.setForeground(TEXT_WHITE);
        q.setBorder(new EmptyBorder(10, 0, 20, 0));
        qCard.add(q);

        // Answer buttons
        String[] options = {"2014", "2016", "2018", "2015"};
        JPanel btnGrid = new JPanel(new GridLayout(2, 2, 10, 10));
        btnGrid.setOpaque(false);
        for (String opt : options) {
            JButton btn = new JButton(opt);
            btn.setBackground(BG_DARK);
            btn.setForeground(TEXT_WHITE);
            btn.setFont(new Font("SansSerif", Font.BOLD, 14));
            btn.setBorder(BorderFactory.createLineBorder(BORDER_COL, 1));
            btn.setFocusPainted(false);
            btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            btn.addActionListener(e -> {
                btn.setBackground(opt.equals("2016") ? new Color(0, 100, 50) : new Color(100, 0, 0));
                scoreLbl.setText(opt.equals("2016") ? "Score: 1 / 10" : "Score: 0 / 10");
            });
            btnGrid.add(btn);
        }
        qCard.add(btnGrid);

        // Next button
        JButton next = new JButton("Next Question →");
        next.setBackground(ACCENT_RED);
        next.setForeground(Color.WHITE);
        next.setFont(new Font("SansSerif", Font.BOLD, 13));
        next.setBorder(new EmptyBorder(10, 20, 10, 20));
        next.setFocusPainted(false);
        next.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        JPanel btnWrap = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnWrap.setOpaque(false);
        btnWrap.add(next);
        qCard.add(Box.createVerticalStrut(12));
        qCard.add(btnWrap);

        root.add(qCard, BorderLayout.CENTER);
        return root;
    }

    // ══════════════════════════════════════════════════════════
    // CUSTOM BAR CHART (Graphics2D)
    // ══════════════════════════════════════════════════════════
    class BarChartPanel extends JPanel {
        String[] labels = {"VER", "LEC", "HAM", "NOR", "SAI", "PER", "RUS"};
        int[]    values = { 77,    62,    55,    44,    38,    31,    24  };
        Color[]  colors = {
            new Color(54, 113, 198),   // Red Bull blue
            new Color(232, 0, 45),     // Ferrari red
            new Color(39, 244, 210),   // Mercedes teal
            new Color(255, 128, 0),    // McLaren orange
            new Color(232, 0, 45),     // Ferrari red (Sainz)
            new Color(54, 113, 198),   // Red Bull blue (Perez)
            new Color(39, 244, 210),   // Mercedes teal (Russell)
        };

        BarChartPanel() {
            setBackground(BG_PANEL);
            setPreferredSize(new Dimension(400, 250));
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int w = getWidth(), h = getHeight();
            int pad = 30, barW = (w - pad * 2) / labels.length - 8;
            int maxVal = 100;

            for (int i = 0; i < labels.length; i++) {
                int barH = (int) ((values[i] / (double) maxVal) * (h - pad * 2));
                int x = pad + i * ((w - pad * 2) / labels.length);
                int y = h - pad - barH;

                g2.setColor(colors[i]);
                g2.fillRoundRect(x, y, barW, barH, 4, 4);

                g2.setColor(TEXT_WHITE);
                g2.setFont(new Font("Monospaced", Font.BOLD, 10));
                g2.drawString(String.valueOf(values[i]), x + barW / 2 - 8, y - 4);

                g2.setColor(TEXT_GREY);
                g2.setFont(new Font("SansSerif", Font.BOLD, 11));
                g2.drawString(labels[i], x + barW / 2 - 10, h - 8);
            }
        }
    }

    // ══════════════════════════════════════════════════════════
    // HELPERS
    // ══════════════════════════════════════════════════════════
    JPanel darkPanel(LayoutManager layout) {
        JPanel p = new JPanel(layout);
        p.setBackground(BG_DARK);
        return p;
    }

    JPanel titledCard(String title) {
        JPanel card = new JPanel();
        card.setBackground(BG_PANEL);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COL, 1),
            new EmptyBorder(14, 16, 14, 16)
        ));
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));

        JLabel lbl = new JLabel(title);
        lbl.setFont(new Font("Monospaced", Font.BOLD, 11));
        lbl.setForeground(ACCENT_RED);
        lbl.setBorder(new EmptyBorder(0, 0, 10, 0));
        card.add(lbl);
        return card;
    }

    JPanel wrapTable(String title, String[] cols, Object[][] data) {
        JPanel card = new JPanel(new BorderLayout(0, 8));
        card.setBackground(BG_PANEL);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COL, 1),
            new EmptyBorder(14, 14, 14, 14)
        ));

        JLabel lbl = new JLabel(title);
        lbl.setFont(new Font("Monospaced", Font.BOLD, 11));
        lbl.setForeground(ACCENT_RED);
        card.add(lbl, BorderLayout.NORTH);

        DefaultTableModel model = new DefaultTableModel(data, cols) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = new JTable(model);
        table.setBackground(BG_PANEL);
        table.setForeground(TEXT_WHITE);
        table.setFont(new Font("SansSerif", Font.PLAIN, 13));
        table.setRowHeight(28);
        table.setGridColor(BORDER_COL);
        table.setShowGrid(true);
        table.setSelectionBackground(new Color(50, 50, 70));
        table.setSelectionForeground(TEXT_WHITE);
        table.getTableHeader().setBackground(new Color(15, 15, 25));
        table.getTableHeader().setForeground(TEXT_GREY);
        table.getTableHeader().setFont(new Font("Monospaced", Font.BOLD, 12));

        JScrollPane scroll = new JScrollPane(table);
        scroll.getViewport().setBackground(BG_PANEL);
        scroll.setBorder(null);
        card.add(scroll, BorderLayout.CENTER);
        return card;
    }

    JLabel bigLabel(String text, int size, Color color) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Monospaced", Font.BOLD, size));
        l.setForeground(color);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        return l;
    }

    JLabel smallLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("SansSerif", Font.PLAIN, 12));
        l.setForeground(TEXT_GREY);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        return l;
    }

    // ── MAIN ───────────────────────────────────────────────────
    public static void main(String[] args) {
        SwingUtilities.invokeLater(PitWallDashboard::new);
    }
}
