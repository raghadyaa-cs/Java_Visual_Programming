
import java.awt.Color;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Dashboard extends javax.swing.JFrame {

    public Dashboard(String username, boolean isMember) {
        initComponents();

        lblConsTitle.setForeground(new java.awt.Color(136, 136, 136));
        lblConsTitle.setFont(new java.awt.Font("Consolas", java.awt.Font.PLAIN, 9));
        lblPos1.setForeground(new java.awt.Color(255, 215, 0));
        lblPos1.setFont(new java.awt.Font("Consolas", java.awt.Font.BOLD, 12));
        lblPos2.setForeground(new java.awt.Color(255, 215, 0));
        lblPos2.setFont(new java.awt.Font("Consolas", java.awt.Font.BOLD, 12));
        lblPos3.setForeground(new java.awt.Color(136, 136, 136));
        lblPos3.setFont(new java.awt.Font("Consolas", java.awt.Font.BOLD, 12));
        lblPos4.setForeground(new java.awt.Color(136, 136, 136));
        lblPos4.setFont(new java.awt.Font("Consolas", java.awt.Font.BOLD, 12));
        lblPos5.setForeground(new java.awt.Color(136, 136, 136));
        lblPos5.setFont(new java.awt.Font("Consolas", java.awt.Font.BOLD, 12));
        lblTeam1.setForeground(new java.awt.Color(54, 113, 198));
        lblTeam2.setForeground(new java.awt.Color(220, 0, 0));
        lblTeam3.setForeground(new java.awt.Color(0, 210, 190));
        lblTeam4.setForeground(new java.awt.Color(255, 128, 0));
        lblTeam5.setForeground(new java.awt.Color(53, 140, 117));

        lblPts1.setForeground(java.awt.Color.WHITE);
        lblPts1.setBackground(new java.awt.Color(54, 113, 198));
        lblPts1.setOpaque(true);
        lblPts1.setFont(new java.awt.Font("Consolas", java.awt.Font.BOLD, 10));
        lblPts1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPts2.setForeground(java.awt.Color.WHITE);
        lblPts2.setBackground(new java.awt.Color(220, 0, 0));
        lblPts2.setOpaque(true);
        lblPts2.setFont(new java.awt.Font("Consolas", java.awt.Font.BOLD, 10));
        lblPts2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPts3.setForeground(java.awt.Color.WHITE);
        lblPts3.setBackground(new java.awt.Color(0, 210, 190));
        lblPts3.setOpaque(true);
        lblPts3.setFont(new java.awt.Font("Consolas", java.awt.Font.BOLD, 10));
        lblPts3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPts4.setForeground(java.awt.Color.WHITE);
        lblPts4.setBackground(new java.awt.Color(255, 128, 0));
        lblPts4.setOpaque(true);
        lblPts4.setFont(new java.awt.Font("Consolas", java.awt.Font.BOLD, 10));
        lblPts4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPts5.setForeground(java.awt.Color.WHITE);
        lblPts5.setBackground(new java.awt.Color(53, 140, 117));
        lblPts5.setOpaque(true);
        lblPts5.setFont(new java.awt.Font("Consolas", java.awt.Font.BOLD, 10));
        lblPts5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        lblUsername.setText(Register.savedFullName);
        lblUserNickname.setText(Register.savedUsername);
        lblFavDriverTag.setText(Register.savedDriver);
        lblLastLogInTag.setText(FileHelper.getLastLogin(username));
        lblDaysStreak.setVisible(true);
        lblDaysStreak.setText(FileHelper.getLoginCount(username) + " Days");
        javax.swing.Timer scoreRefresh = new javax.swing.Timer(2000, e -> {
            lblTriviaScore.setText(TriviaFrame.highestScore + " Points");
        });
        scoreRefresh.start();
        lblWelcomeLabel.setText("Welcome, " + username);

        java.time.LocalDate today = java.time.LocalDate.now();
        String gpName = "Season Complete";
        String gpCircuit = "—";
        String gpDate = null;

        if (today.isBefore(java.time.LocalDate.of(2026, 6, 19))) {
            gpName = "Canadian Grand Prix";
            gpCircuit = "Circuit Gilles Villeneuve · Round 10 of 24";
            gpDate = "2026-06-19";
        } else if (today.isBefore(java.time.LocalDate.of(2026, 6, 28))) {
            gpName = "Austrian Grand Prix";
            gpCircuit = "Red Bull Ring · Round 11 of 24";
            gpDate = "2026-06-28";
        } else if (today.isBefore(java.time.LocalDate.of(2026, 7, 5))) {
            gpName = "British Grand Prix";
            gpCircuit = "Silverstone Circuit · Round 12 of 24";
            gpDate = "2026-07-05";
        } else if (today.isBefore(java.time.LocalDate.of(2026, 7, 19))) {
            gpName = "Hungarian Grand Prix";
            gpCircuit = "Hungaroring · Round 13 of 24";
            gpDate = "2026-07-19";
        } else if (today.isBefore(java.time.LocalDate.of(2026, 7, 26))) {
            gpName = "Belgian Grand Prix";
            gpCircuit = "Circuit de Spa · Round 14 of 24";
            gpDate = "2026-07-26";
        } else if (today.isBefore(java.time.LocalDate.of(2026, 8, 23))) {
            gpName = "Dutch Grand Prix";
            gpCircuit = "Circuit Zandvoort · Round 15 of 24";
            gpDate = "2026-08-23";
        } else if (today.isBefore(java.time.LocalDate.of(2026, 9, 6))) {
            gpName = "Italian Grand Prix";
            gpCircuit = "Autodromo Nazionale Monza · Round 16 of 24";
            gpDate = "2026-09-06";
        } else if (today.isBefore(java.time.LocalDate.of(2026, 9, 20))) {
            gpName = "Azerbaijan Grand Prix";
            gpCircuit = "Baku City Circuit · Round 17 of 24";
            gpDate = "2026-09-20";
        } else if (today.isBefore(java.time.LocalDate.of(2026, 10, 4))) {
            gpName = "Singapore Grand Prix";
            gpCircuit = "Marina Bay Street Circuit · Round 18 of 24";
            gpDate = "2026-10-04";
        } else if (today.isBefore(java.time.LocalDate.of(2026, 10, 18))) {
            gpName = "United States Grand Prix";
            gpCircuit = "Circuit of the Americas · Round 19 of 24";
            gpDate = "2026-10-18";
        } else if (today.isBefore(java.time.LocalDate.of(2026, 10, 25))) {
            gpName = "Mexico City Grand Prix";
            gpCircuit = "Autodromo Hermanos Rodriguez · Round 20 of 24";
            gpDate = "2026-10-25";
        } else if (today.isBefore(java.time.LocalDate.of(2026, 11, 8))) {
            gpName = "Sao Paulo Grand Prix";
            gpCircuit = "Autodromo Jose Carlos Pace · Round 21 of 24";
            gpDate = "2026-11-08";
        } else if (today.isBefore(java.time.LocalDate.of(2026, 11, 22))) {
            gpName = "Las Vegas Grand Prix";
            gpCircuit = "Las Vegas Strip Circuit · Round 22 of 24";
            gpDate = "2026-11-22";
        } else if (today.isBefore(java.time.LocalDate.of(2026, 11, 29))) {
            gpName = "Qatar Grand Prix";
            gpCircuit = "Lusail International Circuit · Round 23 of 24";
            gpDate = "2026-11-29";
        } else if (today.isBefore(java.time.LocalDate.of(2026, 12, 6))) {
            gpName = "Abu Dhabi Grand Prix";
            gpCircuit = "Yas Marina Circuit · Round 24 of 24";
            gpDate = "2026-12-06";
        }

// Set labels
        lblGPname.setText(gpName);
        lblRoundNumber.setText(gpCircuit);

// Start countdown if race found
        if (gpDate != null) {
            java.time.LocalDate raceDay = java.time.LocalDate.parse(gpDate);
            java.util.Calendar nextRaceCal = java.util.Calendar.getInstance();
            nextRaceCal.set(raceDay.getYear(), raceDay.getMonthValue() - 1,
                    raceDay.getDayOfMonth(), 0, 0, 0);

            javax.swing.Timer countdownTimer = new javax.swing.Timer(1000, e -> {
                long diff = nextRaceCal.getTimeInMillis() - System.currentTimeMillis();
                if (diff <= 0) {
                    lblCounter.setText("Race is ON!");
                    return;
                }
                long days = diff / (1000 * 60 * 60 * 24);
                long hours = (diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60);
                long mins = (diff % (1000 * 60 * 60)) / (1000 * 60);
                long secs = (diff % (1000 * 60)) / 1000;
                lblCounter.setText(days + "Days:" + String.format("%02d", hours) + "Hours  "
                        + String.format("%02d", mins) + "Mins:" + String.format("%02d", secs) + "Secs");
            });
            countdownTimer.start();
        } else {
            lblCounter.setText("Season Complete!");
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlLogo = new javax.swing.JPanel();
        lblLogo = new javax.swing.JLabel();
        lblLogoP = new javax.swing.JLabel();
        btnLogOut = new javax.swing.JButton();
        pnlFastestLaps = new javax.swing.JPanel();
        lblFastestLaps = new javax.swing.JLabel();
        lblFirstFastestLapNumber = new javax.swing.JLabel();
        lblSecondFastestLapNumber = new javax.swing.JLabel();
        lblThirdFastestLapNumber = new javax.swing.JLabel();
        lblSecondFastestDriver = new javax.swing.JLabel();
        lblFirstFastestDriver = new javax.swing.JLabel();
        lblThirdFastestDriver = new javax.swing.JLabel();
        lblFirstFastestLapTime = new javax.swing.JLabel();
        lblSecondFastestLapTime = new javax.swing.JLabel();
        lblThirdFastestLapTime = new javax.swing.JLabel();
        pnlDriversStandings = new javax.swing.JPanel();
        lblStandings = new javax.swing.JLabel();
        lblFirstPole = new javax.swing.JLabel();
        lblFirstDriverName = new javax.swing.JLabel();
        lblFirstDriverTeam = new javax.swing.JLabel();
        lblFirstDriverPoints = new javax.swing.JLabel();
        lblSecondPole = new javax.swing.JLabel();
        lblThirdPole = new javax.swing.JLabel();
        lblSecondDriverName = new javax.swing.JLabel();
        lblSecondDriverTeam = new javax.swing.JLabel();
        lblThirdDriverName = new javax.swing.JLabel();
        lblThirdDriverTeam = new javax.swing.JLabel();
        lblSecondDriverPoints = new javax.swing.JLabel();
        lblThirdDriverPoints = new javax.swing.JLabel();
        pnlCountDown = new javax.swing.JPanel();
        lblCountdown = new javax.swing.JLabel();
        lblGPname = new javax.swing.JLabel();
        lblRoundNumber = new javax.swing.JLabel();
        lblCounter = new javax.swing.JLabel();
        pnlNews = new javax.swing.JPanel();
        lblNews = new javax.swing.JLabel();
        lblFirstNews = new javax.swing.JLabel();
        lblF1News = new javax.swing.JLabel();
        lblTeamsNews = new javax.swing.JLabel();
        lblTechNews = new javax.swing.JLabel();
        lblsecondNesTime = new javax.swing.JLabel();
        lblSecondNews = new javax.swing.JLabel();
        lblThirdNews = new javax.swing.JLabel();
        lblFirstnewsTime = new javax.swing.JLabel();
        lblthirdNewsTime = new javax.swing.JLabel();
        btnMoreNews = new javax.swing.JButton();
        pnlWelcomeUser = new javax.swing.JPanel();
        lblUsernameTag = new javax.swing.JLabel();
        lblUserInfoHeader = new javax.swing.JLabel();
        lblTriviaStreakTag = new javax.swing.JLabel();
        lblFavDriverTag = new javax.swing.JLabel();
        lblLastLogInTag = new javax.swing.JLabel();
        lblHighestTriviaScoreTag = new javax.swing.JLabel();
        lblUserNicknameTag = new javax.swing.JLabel();
        btnProfile = new javax.swing.JButton();
        lblDaysStreak = new javax.swing.JLabel();
        lblUsername = new javax.swing.JLabel();
        lblUserNickname = new javax.swing.JLabel();
        lblFavDriver = new javax.swing.JLabel();
        lblLastLogIn = new javax.swing.JLabel();
        lblTriviaScore = new javax.swing.JLabel();
        lblWelcomeUser = new javax.swing.JLabel();
        lblMyProjectCredits = new javax.swing.JLabel();
        lblWelcomeLabel = new javax.swing.JLabel();
        lblMyProjectCredits2 = new javax.swing.JLabel();
        pnlConstructorStandings = new javax.swing.JPanel();
        lblConsTitle = new javax.swing.JLabel();
        lblPos1 = new javax.swing.JLabel();
        lblPos2 = new javax.swing.JLabel();
        lblPos3 = new javax.swing.JLabel();
        lblPos4 = new javax.swing.JLabel();
        lblPos5 = new javax.swing.JLabel();
        lblTeam1 = new javax.swing.JLabel();
        lblTeam3 = new javax.swing.JLabel();
        lblTeam2 = new javax.swing.JLabel();
        lblTeam4 = new javax.swing.JLabel();
        lblTeam5 = new javax.swing.JLabel();
        lblPts1 = new javax.swing.JLabel();
        lblPts2 = new javax.swing.JLabel();
        lblPts3 = new javax.swing.JLabel();
        lblPts4 = new javax.swing.JLabel();
        lblPts5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("PitWall - F1 Fan App - Dashboard");
        setBackground(new java.awt.Color(0, 51, 51));

        pnlLogo.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        lblLogo.setFont(new java.awt.Font("Tahoma", 3, 48)); // NOI18N
        lblLogo.setText("PitWall");

        lblLogoP.setFont(new java.awt.Font("Tahoma", 3, 48)); // NOI18N
        lblLogoP.setForeground(new java.awt.Color(255, 0, 0));
        lblLogoP.setText("P");

        javax.swing.GroupLayout pnlLogoLayout = new javax.swing.GroupLayout(pnlLogo);
        pnlLogo.setLayout(pnlLogoLayout);
        pnlLogoLayout.setHorizontalGroup(
            pnlLogoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlLogoLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblLogoP)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblLogo, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        pnlLogoLayout.setVerticalGroup(
            pnlLogoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlLogoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlLogoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblLogo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblLogoP))
                .addContainerGap())
        );

        btnLogOut.setForeground(new java.awt.Color(0, 0, 102));
        btnLogOut.setText("Back To Main Menu");
        btnLogOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogOutActionPerformed(evt);
            }
        });

        pnlFastestLaps.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        lblFastestLaps.setText("Fastest Laps:");

        lblFirstFastestLapNumber.setText("Lap 45");

        lblSecondFastestLapNumber.setText("Lap 42");

        lblThirdFastestLapNumber.setText("Lap 44");

        lblSecondFastestDriver.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        lblSecondFastestDriver.setForeground(new java.awt.Color(255, 153, 0));
        lblSecondFastestDriver.setText("Norris");

        lblFirstFastestDriver.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        lblFirstFastestDriver.setForeground(new java.awt.Color(0, 0, 102));
        lblFirstFastestDriver.setText("Verstappen");

        lblThirdFastestDriver.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        lblThirdFastestDriver.setForeground(new java.awt.Color(255, 0, 0));
        lblThirdFastestDriver.setText("Leclerc");

        lblFirstFastestLapTime.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        lblFirstFastestLapTime.setText("1:31:447");

        lblSecondFastestLapTime.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        lblSecondFastestLapTime.setText("1:31:892");

        lblThirdFastestLapTime.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        lblThirdFastestLapTime.setText("1:32:110");

        javax.swing.GroupLayout pnlFastestLapsLayout = new javax.swing.GroupLayout(pnlFastestLaps);
        pnlFastestLaps.setLayout(pnlFastestLapsLayout);
        pnlFastestLapsLayout.setHorizontalGroup(
            pnlFastestLapsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlFastestLapsLayout.createSequentialGroup()
                .addComponent(lblFastestLaps)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(pnlFastestLapsLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(pnlFastestLapsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblSecondFastestLapNumber)
                    .addComponent(lblFirstFastestLapNumber)
                    .addComponent(lblThirdFastestLapNumber))
                .addGap(26, 26, 26)
                .addGroup(pnlFastestLapsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblSecondFastestDriver, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblFirstFastestDriver, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblThirdFastestDriver, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlFastestLapsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblSecondFastestLapTime, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblThirdFastestLapTime, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblFirstFastestLapTime))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlFastestLapsLayout.setVerticalGroup(
            pnlFastestLapsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlFastestLapsLayout.createSequentialGroup()
                .addComponent(lblFastestLaps)
                .addGap(6, 6, 6)
                .addGroup(pnlFastestLapsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblFirstFastestDriver, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblFirstFastestLapNumber)
                    .addComponent(lblFirstFastestLapTime))
                .addGap(13, 13, 13)
                .addGroup(pnlFastestLapsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSecondFastestDriver, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblSecondFastestLapNumber)
                    .addComponent(lblSecondFastestLapTime))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlFastestLapsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblThirdFastestDriver, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblThirdFastestLapNumber)
                    .addComponent(lblThirdFastestLapTime))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnlDriversStandings.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        lblStandings.setText("Drivers' Standings:");

        lblFirstPole.setForeground(new java.awt.Color(204, 204, 0));
        lblFirstPole.setText("1st");

        lblFirstDriverName.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblFirstDriverName.setText("Max Verstappen");

        lblFirstDriverTeam.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        lblFirstDriverTeam.setForeground(new java.awt.Color(54, 113, 198));
        lblFirstDriverTeam.setText("Red Bull Racing Team");

        lblFirstDriverPoints.setForeground(new java.awt.Color(54, 113, 198));
        lblFirstDriverPoints.setText("77 points");

        lblSecondPole.setForeground(new java.awt.Color(153, 153, 153));
        lblSecondPole.setText("2nd");

        lblThirdPole.setText("3rd");

        lblSecondDriverName.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblSecondDriverName.setText("Charles Leclerc");

        lblSecondDriverTeam.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        lblSecondDriverTeam.setForeground(new java.awt.Color(220, 0, 0));
        lblSecondDriverTeam.setText("Ferrari");

        lblThirdDriverName.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblThirdDriverName.setText("Lewis Hamilton");

        lblThirdDriverTeam.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        lblThirdDriverTeam.setForeground(new java.awt.Color(0, 210, 190));
        lblThirdDriverTeam.setText("Mercedes");

        lblSecondDriverPoints.setForeground(new java.awt.Color(220, 0, 0));
        lblSecondDriverPoints.setText("62 points");

        lblThirdDriverPoints.setForeground(new java.awt.Color(0, 210, 190));
        lblThirdDriverPoints.setText("55 points");

        javax.swing.GroupLayout pnlDriversStandingsLayout = new javax.swing.GroupLayout(pnlDriversStandings);
        pnlDriversStandings.setLayout(pnlDriversStandingsLayout);
        pnlDriversStandingsLayout.setHorizontalGroup(
            pnlDriversStandingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDriversStandingsLayout.createSequentialGroup()
                .addGroup(pnlDriversStandingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlDriversStandingsLayout.createSequentialGroup()
                        .addComponent(lblStandings)
                        .addGap(0, 73, Short.MAX_VALUE))
                    .addGroup(pnlDriversStandingsLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(pnlDriversStandingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlDriversStandingsLayout.createSequentialGroup()
                                .addComponent(lblThirdPole)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(pnlDriversStandingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(pnlDriversStandingsLayout.createSequentialGroup()
                                        .addComponent(lblThirdDriverTeam)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlDriversStandingsLayout.createSequentialGroup()
                                        .addComponent(lblThirdDriverName)
                                        .addGap(0, 0, Short.MAX_VALUE))))
                            .addGroup(pnlDriversStandingsLayout.createSequentialGroup()
                                .addComponent(lblFirstPole, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(pnlDriversStandingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblFirstDriverTeam)
                                    .addComponent(lblFirstDriverName))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(pnlDriversStandingsLayout.createSequentialGroup()
                                .addComponent(lblSecondPole)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(pnlDriversStandingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblSecondDriverTeam)
                                    .addComponent(lblSecondDriverName))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlDriversStandingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblSecondDriverPoints)
                    .addComponent(lblThirdDriverPoints)
                    .addComponent(lblFirstDriverPoints))
                .addGap(15, 15, 15))
        );
        pnlDriversStandingsLayout.setVerticalGroup(
            pnlDriversStandingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDriversStandingsLayout.createSequentialGroup()
                .addComponent(lblStandings)
                .addGap(18, 18, 18)
                .addGroup(pnlDriversStandingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlDriversStandingsLayout.createSequentialGroup()
                        .addGroup(pnlDriversStandingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlDriversStandingsLayout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(lblFirstPole))
                            .addComponent(lblFirstDriverName, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(lblFirstDriverTeam)
                        .addGap(18, 18, 18)
                        .addGroup(pnlDriversStandingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblSecondDriverName)
                            .addComponent(lblSecondPole))
                        .addGap(7, 7, 7)
                        .addComponent(lblSecondDriverTeam)
                        .addGap(18, 18, 18)
                        .addGroup(pnlDriversStandingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblThirdPole)
                            .addComponent(lblThirdDriverName)))
                    .addGroup(pnlDriversStandingsLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblFirstDriverPoints)
                        .addGap(31, 31, 31)
                        .addComponent(lblSecondDriverPoints)
                        .addGap(38, 38, 38)
                        .addComponent(lblThirdDriverPoints)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblThirdDriverTeam)
                .addGap(20, 20, 20))
        );

        pnlCountDown.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        lblCountdown.setText("Next Race Countdown:");

        lblGPname.setFont(new java.awt.Font("SansSerif", 3, 45)); // NOI18N
        lblGPname.setForeground(new java.awt.Color(0, 51, 51));
        lblGPname.setText("Saudi Arabia GP");

        lblRoundNumber.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        lblRoundNumber.setText("Jeddah Corniche Circut , Round 4 of 24");

        lblCounter.setText("jLabel1");

        javax.swing.GroupLayout pnlCountDownLayout = new javax.swing.GroupLayout(pnlCountDown);
        pnlCountDown.setLayout(pnlCountDownLayout);
        pnlCountDownLayout.setHorizontalGroup(
            pnlCountDownLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCountDownLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblCounter, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(pnlCountDownLayout.createSequentialGroup()
                .addGroup(pnlCountDownLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlCountDownLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(lblGPname, javax.swing.GroupLayout.PREFERRED_SIZE, 367, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlCountDownLayout.createSequentialGroup()
                        .addGroup(pnlCountDownLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblCountdown)
                            .addComponent(lblRoundNumber))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        pnlCountDownLayout.setVerticalGroup(
            pnlCountDownLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlCountDownLayout.createSequentialGroup()
                .addComponent(lblCountdown)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblGPname, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblCounter, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblRoundNumber)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnlNews.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        lblNews.setText("Latest News:");

        lblFirstNews.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblFirstNews.setForeground(new java.awt.Color(0, 0, 153));
        lblFirstNews.setText("Verstappen dominates Bahrain GP, extends championship lead.");

        lblF1News.setText("F1");

        lblTeamsNews.setText("Teams");

        lblTechNews.setText("Tech");

        lblsecondNesTime.setText("4 hours ago , AutoStop");

        lblSecondNews.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblSecondNews.setForeground(new java.awt.Color(255, 0, 0));
        lblSecondNews.setText("Ferrari confirm upgrade package for Saudi Arabia race weekend.");

        lblThirdNews.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblThirdNews.setForeground(new java.awt.Color(255, 102, 0));
        lblThirdNews.setText("McLaren's new floor design under scrutiny after Bahrain data analysis.");

        lblFirstnewsTime.setText("2 hours ago , www.f1.com");

        lblthirdNewsTime.setText("6 hours ago , The Race");

        btnMoreNews.setText("More News ->");
        btnMoreNews.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMoreNewsActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlNewsLayout = new javax.swing.GroupLayout(pnlNews);
        pnlNews.setLayout(pnlNewsLayout);
        pnlNewsLayout.setHorizontalGroup(
            pnlNewsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlNewsLayout.createSequentialGroup()
                .addComponent(lblNews)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(pnlNewsLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlNewsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlNewsLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(lblF1News)
                        .addGap(518, 518, 518))
                    .addGroup(pnlNewsLayout.createSequentialGroup()
                        .addGroup(pnlNewsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblTeamsNews)
                            .addComponent(lblTechNews))
                        .addGap(17, 17, 17)
                        .addGroup(pnlNewsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblThirdNews, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(pnlNewsLayout.createSequentialGroup()
                                .addComponent(lblthirdNewsTime)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnMoreNews))
                            .addGroup(pnlNewsLayout.createSequentialGroup()
                                .addGroup(pnlNewsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblSecondNews, javax.swing.GroupLayout.PREFERRED_SIZE, 474, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblFirstnewsTime)
                                    .addComponent(lblFirstNews, javax.swing.GroupLayout.PREFERRED_SIZE, 474, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblsecondNesTime))
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        pnlNewsLayout.setVerticalGroup(
            pnlNewsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlNewsLayout.createSequentialGroup()
                .addComponent(lblNews)
                .addGap(11, 11, 11)
                .addGroup(pnlNewsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblF1News)
                    .addComponent(lblFirstNews))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblFirstnewsTime)
                .addGap(5, 5, 5)
                .addGroup(pnlNewsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSecondNews)
                    .addComponent(lblTeamsNews))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblsecondNesTime)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlNewsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblThirdNews)
                    .addComponent(lblTechNews))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlNewsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblthirdNewsTime)
                    .addComponent(btnMoreNews))
                .addGap(4, 4, 4))
        );

        pnlWelcomeUser.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        lblUsernameTag.setText("Username");

        lblUserInfoHeader.setText("User Info :");

        lblTriviaStreakTag.setText("Highest Daily Trivia Streak:");

        lblFavDriverTag.setText("Favourite Driver:");

        lblLastLogInTag.setText("Last Log In:");

        lblHighestTriviaScoreTag.setText("Highest Trivia Score:");

        lblUserNicknameTag.setText("User NickName");

        btnProfile.setText("My Profile");
        btnProfile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProfileActionPerformed(evt);
            }
        });

        lblDaysStreak.setText("17Days");

        lblUsername.setText("Raghad Yaser AbuAtwan");

        lblUserNickname.setText("RUGGYAA");

        lblFavDriver.setText("Carlos Sainz");

        lblLastLogIn.setText("26 January 2026 , 4:36 PM");

        lblTriviaScore.setText("0 Points");

        lblWelcomeUser.setText("Welcome !!!!!!!");

        javax.swing.GroupLayout pnlWelcomeUserLayout = new javax.swing.GroupLayout(pnlWelcomeUser);
        pnlWelcomeUser.setLayout(pnlWelcomeUserLayout);
        pnlWelcomeUserLayout.setHorizontalGroup(
            pnlWelcomeUserLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlWelcomeUserLayout.createSequentialGroup()
                .addGroup(pnlWelcomeUserLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlWelcomeUserLayout.createSequentialGroup()
                        .addGroup(pnlWelcomeUserLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlWelcomeUserLayout.createSequentialGroup()
                                .addGap(40, 40, 40)
                                .addComponent(lblUsernameTag)
                                .addGap(37, 37, 37))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlWelcomeUserLayout.createSequentialGroup()
                                .addComponent(lblUserNicknameTag)
                                .addGap(18, 18, 18)))
                        .addGroup(pnlWelcomeUserLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblUserNickname)
                            .addComponent(lblUsername)))
                    .addGroup(pnlWelcomeUserLayout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addGroup(pnlWelcomeUserLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlWelcomeUserLayout.createSequentialGroup()
                                .addGroup(pnlWelcomeUserLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblHighestTriviaScoreTag)
                                    .addGroup(pnlWelcomeUserLayout.createSequentialGroup()
                                        .addGap(10, 10, 10)
                                        .addComponent(lblFavDriverTag)))
                                .addGap(24, 24, 24)
                                .addComponent(lblFavDriver))
                            .addComponent(lblLastLogInTag)
                            .addGroup(pnlWelcomeUserLayout.createSequentialGroup()
                                .addGap(91, 91, 91)
                                .addGroup(pnlWelcomeUserLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblLastLogIn)
                                    .addComponent(btnProfile)))))
                    .addGroup(pnlWelcomeUserLayout.createSequentialGroup()
                        .addGap(145, 145, 145)
                        .addComponent(lblUserInfoHeader))
                    .addGroup(pnlWelcomeUserLayout.createSequentialGroup()
                        .addGap(125, 125, 125)
                        .addComponent(lblWelcomeUser))
                    .addGroup(pnlWelcomeUserLayout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(lblTriviaStreakTag)
                        .addGap(42, 42, 42)
                        .addGroup(pnlWelcomeUserLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblTriviaScore)
                            .addComponent(lblDaysStreak))))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        pnlWelcomeUserLayout.setVerticalGroup(
            pnlWelcomeUserLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlWelcomeUserLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblWelcomeUser)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlWelcomeUserLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblUsername)
                    .addComponent(lblUsernameTag))
                .addGap(10, 10, 10)
                .addGroup(pnlWelcomeUserLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblUserNicknameTag)
                    .addComponent(lblUserNickname))
                .addGap(18, 18, 18)
                .addComponent(lblUserInfoHeader)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlWelcomeUserLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTriviaStreakTag)
                    .addComponent(lblDaysStreak))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlWelcomeUserLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblHighestTriviaScoreTag)
                    .addComponent(lblTriviaScore))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlWelcomeUserLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblFavDriverTag)
                    .addComponent(lblFavDriver))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlWelcomeUserLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblLastLogInTag)
                    .addComponent(lblLastLogIn))
                .addGap(18, 18, 18)
                .addComponent(btnProfile)
                .addGap(111, 111, 111))
        );

        lblMyProjectCredits.setText("Done By Raghad Yaser AbuAtwan (Student of The Computer Science Departmentin ZUJ) ");

        lblWelcomeLabel.setText("Welcome !");

        lblMyProjectCredits2.setText("Under The Supervision of Dr. Jalal Al Kiswani");

        pnlConstructorStandings.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        lblConsTitle.setText("CONSTRUCTOR STANDINGS");

        lblPos1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblPos1.setText("1");

        lblPos2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblPos2.setText("2");

        lblPos3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblPos3.setText("3");

        lblPos4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblPos4.setText("4");

        lblPos5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblPos5.setText("5");

        lblTeam1.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        lblTeam1.setText(" Red Bull Racing ");

        lblTeam3.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        lblTeam3.setText(" McLaren ");

        lblTeam2.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        lblTeam2.setText(" Ferrari ");

        lblTeam4.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        lblTeam4.setText(" Mercedes ");

        lblTeam5.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        lblTeam5.setText(" Aston Martin ");

        lblPts1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblPts1.setText("106 pts");

        lblPts2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblPts2.setText("106 pts");

        lblPts3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblPts3.setText("70 pts");

        lblPts4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblPts4.setText("92 pts");

        lblPts5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblPts5.setText("33 pts");

        javax.swing.GroupLayout pnlConstructorStandingsLayout = new javax.swing.GroupLayout(pnlConstructorStandings);
        pnlConstructorStandings.setLayout(pnlConstructorStandingsLayout);
        pnlConstructorStandingsLayout.setHorizontalGroup(
            pnlConstructorStandingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlConstructorStandingsLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlConstructorStandingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlConstructorStandingsLayout.createSequentialGroup()
                        .addComponent(lblPos1, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(8, 8, 8))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlConstructorStandingsLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 1, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(pnlConstructorStandingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblPos3, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblPos2, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblPos4, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblPos5, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(pnlConstructorStandingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTeam1)
                    .addComponent(lblTeam2)
                    .addComponent(lblTeam3)
                    .addComponent(lblTeam4)
                    .addComponent(lblTeam5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 145, Short.MAX_VALUE)
                .addGroup(pnlConstructorStandingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblPts1)
                    .addComponent(lblPts2)
                    .addComponent(lblPts5)
                    .addComponent(lblPts3)
                    .addComponent(lblPts4))
                .addGap(23, 23, 23))
            .addGroup(pnlConstructorStandingsLayout.createSequentialGroup()
                .addComponent(lblConsTitle)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pnlConstructorStandingsLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {lblTeam1, lblTeam2, lblTeam3, lblTeam4, lblTeam5});

        pnlConstructorStandingsLayout.setVerticalGroup(
            pnlConstructorStandingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlConstructorStandingsLayout.createSequentialGroup()
                .addComponent(lblConsTitle)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlConstructorStandingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlConstructorStandingsLayout.createSequentialGroup()
                        .addGroup(pnlConstructorStandingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblTeam1)
                            .addComponent(lblPos1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlConstructorStandingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblTeam2)
                            .addComponent(lblPos2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlConstructorStandingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblTeam4)
                            .addComponent(lblPos3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlConstructorStandingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblTeam3)
                            .addComponent(lblPos4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlConstructorStandingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblTeam5)
                            .addComponent(lblPos5)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlConstructorStandingsLayout.createSequentialGroup()
                        .addComponent(lblPts1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblPts2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblPts4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblPts3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblPts5)
                        .addGap(19, 19, 19)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnlConstructorStandingsLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {lblTeam1, lblTeam2, lblTeam3, lblTeam4, lblTeam5});

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(pnlConstructorStandings, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(pnlDriversStandings, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(pnlLogo, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(222, 222, 222)
                                .addComponent(lblWelcomeLabel)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(129, 129, 129)
                                .addComponent(lblMyProjectCredits)
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(pnlCountDown, javax.swing.GroupLayout.PREFERRED_SIZE, 366, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(pnlFastestLaps, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(pnlNews, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(pnlWelcomeUser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(22, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(btnLogOut, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblMyProjectCredits2))
                                .addGap(36, 36, 36))))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnlLogo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(lblMyProjectCredits, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(lblWelcomeLabel)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(pnlCountDown, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(pnlFastestLaps, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(pnlNews, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(pnlWelcomeUser, javax.swing.GroupLayout.PREFERRED_SIZE, 286, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblMyProjectCredits2)
                        .addGap(30, 30, 30)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnlConstructorStandings, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pnlDriversStandings, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addComponent(btnLogOut, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnLogOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogOutActionPerformed
        MainMenu menu = new MainMenu(MainMenu.currentUser, MainMenu.isMember);
        menu.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnLogOutActionPerformed

    private void btnProfileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProfileActionPerformed
        Profile profile = new Profile();
profile.setVisible(true);    }//GEN-LAST:event_btnProfileActionPerformed

    private void btnMoreNewsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMoreNewsActionPerformed
        NewsStandings news = new NewsStandings();
        news.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnMoreNewsActionPerformed

    public static void main(String args[]) {

        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new Dashboard("Guest", false).setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnLogOut;
    private javax.swing.JButton btnMoreNews;
    private javax.swing.JButton btnProfile;
    private javax.swing.JButton btnRightAnswer1;
    private javax.swing.JButton btnWrongAnswer4;
    private javax.swing.JButton btnWrongAnswer5;
    private javax.swing.JButton btnWrongAnswer6;
    private javax.swing.JLabel lblConsTitle;
    private javax.swing.JLabel lblCountdown;
    private javax.swing.JLabel lblCounter;
    private javax.swing.JLabel lblDaysStreak;
    private javax.swing.JLabel lblF1News;
    private javax.swing.JLabel lblFastestLaps;
    private javax.swing.JLabel lblFavDriver;
    private javax.swing.JLabel lblFavDriverTag;
    private javax.swing.JLabel lblFirstDriverName;
    private javax.swing.JLabel lblFirstDriverPoints;
    private javax.swing.JLabel lblFirstDriverTeam;
    private javax.swing.JLabel lblFirstFastestDriver;
    private javax.swing.JLabel lblFirstFastestLapNumber;
    private javax.swing.JLabel lblFirstFastestLapTime;
    private javax.swing.JLabel lblFirstNews;
    private javax.swing.JLabel lblFirstPole;
    private javax.swing.JLabel lblFirstnewsTime;
    private javax.swing.JLabel lblGPname;
    private javax.swing.JLabel lblHighestTriviaScoreTag;
    private javax.swing.JLabel lblLastLogIn;
    private javax.swing.JLabel lblLastLogInTag;
    private javax.swing.JLabel lblLogo;
    private javax.swing.JLabel lblLogoP;
    private javax.swing.JLabel lblMyProjectCredits;
    private javax.swing.JLabel lblMyProjectCredits2;
    private javax.swing.JLabel lblNews;
    private javax.swing.JLabel lblPos1;
    private javax.swing.JLabel lblPos2;
    private javax.swing.JLabel lblPos3;
    private javax.swing.JLabel lblPos4;
    private javax.swing.JLabel lblPos5;
    private javax.swing.JLabel lblPts1;
    private javax.swing.JLabel lblPts2;
    private javax.swing.JLabel lblPts3;
    private javax.swing.JLabel lblPts4;
    private javax.swing.JLabel lblPts5;
    private javax.swing.JLabel lblRoundNumber;
    private javax.swing.JLabel lblSecondDriverName;
    private javax.swing.JLabel lblSecondDriverPoints;
    private javax.swing.JLabel lblSecondDriverTeam;
    private javax.swing.JLabel lblSecondFastestDriver;
    private javax.swing.JLabel lblSecondFastestLapNumber;
    private javax.swing.JLabel lblSecondFastestLapTime;
    private javax.swing.JLabel lblSecondNews;
    private javax.swing.JLabel lblSecondPole;
    private javax.swing.JLabel lblStandings;
    private javax.swing.JLabel lblTeam1;
    private javax.swing.JLabel lblTeam2;
    private javax.swing.JLabel lblTeam3;
    private javax.swing.JLabel lblTeam4;
    private javax.swing.JLabel lblTeam5;
    private javax.swing.JLabel lblTeamsNews;
    private javax.swing.JLabel lblTechNews;
    private javax.swing.JLabel lblThirdDriverName;
    private javax.swing.JLabel lblThirdDriverPoints;
    private javax.swing.JLabel lblThirdDriverTeam;
    private javax.swing.JLabel lblThirdFastestDriver;
    private javax.swing.JLabel lblThirdFastestLapNumber;
    private javax.swing.JLabel lblThirdFastestLapTime;
    private javax.swing.JLabel lblThirdNews;
    private javax.swing.JLabel lblThirdPole;
    private javax.swing.JLabel lblTrivia1;
    private javax.swing.JLabel lblTriviaQuestion1;
    private javax.swing.JLabel lblTriviaScore;
    private javax.swing.JLabel lblTriviaScoreNo1;
    private javax.swing.JLabel lblTriviaStreakTag;
    private javax.swing.JLabel lblUserInfoHeader;
    private javax.swing.JLabel lblUserNickname;
    private javax.swing.JLabel lblUserNicknameTag;
    private javax.swing.JLabel lblUsername;
    private javax.swing.JLabel lblUsernameTag;
    private javax.swing.JLabel lblWelcomeLabel;
    private javax.swing.JLabel lblWelcomeUser;
    private javax.swing.JLabel lblsecondNesTime;
    private javax.swing.JLabel lblthirdNewsTime;
    private javax.swing.JPanel pnlConstructorStandings;
    private javax.swing.JPanel pnlCountDown;
    private javax.swing.JPanel pnlDriversStandings;
    private javax.swing.JPanel pnlFastestLaps;
    private javax.swing.JPanel pnlLogo;
    private javax.swing.JPanel pnlNews;
    private javax.swing.JPanel pnlTrivia1;
    private javax.swing.JPanel pnlWelcomeUser;
    // End of variables declaration//GEN-END:variables
}
