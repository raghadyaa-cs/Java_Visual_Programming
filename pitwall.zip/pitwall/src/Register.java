
public class Register extends javax.swing.JFrame {

    public static String savedUsername = "";
    public static String savedPassword = "";
    public static String savedFullName = "";
    public static String savedEmail = "";
    public static String savedDriver = "";
    public static String savedDOB = "";

    public Register() {
        initComponents();
       
        getContentPane().setBackground(Theme.BG);
        Theme.stylePanel(pnlAll);
        Theme.styleMuted(lblFullName); // "Full Name" etc
        Theme.styleMuted(lblUsername);
        Theme.styleMuted(lblPassword);
        Theme.styleMuted(lblPasswordConfirm);
        Theme.styleMuted(lblEmail);
        Theme.styleMuted(lblFavDriver);
        Theme.styleField(txtFullName);
        Theme.styleField(txtUsername);
        Theme.styleField(txtEmail);
        Theme.styleButton(btnRegister);
        Theme.styleButton(btnBackToLogIn);
        lblMessage.setForeground(Theme.MUTED);
        lblMessage.setFont(Theme.SMALL);
        cmbFavDriver.setBackground(new java.awt.Color(30, 30, 42));
        cmbFavDriver.setForeground(Theme.TEXT);
        cmbFavDriver.setFont(Theme.BODY);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlLogo2 = new javax.swing.JPanel();
        lblLogo2 = new javax.swing.JLabel();
        lblLogoP2 = new javax.swing.JLabel();
        btnBackToLogIn = new javax.swing.JButton();
        lblMessage = new javax.swing.JLabel();
        pnlAll = new javax.swing.JPanel();
        txtUsername = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        cmbFavDriver = new javax.swing.JComboBox<>();
        txtPassword = new javax.swing.JTextField();
        txtPasswordConfirm = new javax.swing.JTextField();
        lblPasswordConfirm = new javax.swing.JLabel();
        txtFullName = new javax.swing.JTextField();
        lblFullName = new javax.swing.JLabel();
        lblFavDriver = new javax.swing.JLabel();
        btnRegister = new javax.swing.JButton();
        lblPassword = new javax.swing.JLabel();
        lblEmail = new javax.swing.JLabel();
        lblUsername = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("PitWall - F1 Fan DashBoard App - Register");
        setResizable(false);

        pnlLogo2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        lblLogo2.setFont(new java.awt.Font("Tahoma", 3, 48)); // NOI18N
        lblLogo2.setText("PitWall");

        lblLogoP2.setFont(new java.awt.Font("Tahoma", 3, 48)); // NOI18N
        lblLogoP2.setForeground(new java.awt.Color(255, 0, 0));
        lblLogoP2.setText("P");

        javax.swing.GroupLayout pnlLogo2Layout = new javax.swing.GroupLayout(pnlLogo2);
        pnlLogo2.setLayout(pnlLogo2Layout);
        pnlLogo2Layout.setHorizontalGroup(
            pnlLogo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlLogo2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblLogoP2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblLogo2, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        pnlLogo2Layout.setVerticalGroup(
            pnlLogo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlLogo2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlLogo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblLogo2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblLogoP2))
                .addContainerGap())
        );

        btnBackToLogIn.setText("Back to Log In");
        btnBackToLogIn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackToLogInActionPerformed(evt);
            }
        });

        pnlAll.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        txtUsername.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUsernameActionPerformed(evt);
            }
        });

        cmbFavDriver.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Driver", "Max Verstappen – Red Bull Racing", "Liam Lawson – Racing Bulls", "Lewis Hamilton – Ferrari", "Charles Leclerc – Ferrari", "George Russell – Mercedes", "Andrea Kimi Antonelli – Mercedes", "Lando Norris – McLaren", "Oscar Piastri – McLaren", "Fernando Alonso – Aston Martin", "Lance Stroll – Aston Martin", "Pierre Gasly – Alpine", "Franco Colapinto – Alpine", "Carlos Sainz – Williams", "Alex Albon – Williams", "Nico Hülkenberg – Stake F1 Team Kick Sauber", "Gabriel Bortoleto – Stake F1 Team Kick Sauber", "Esteban Ocon – Haas F1 Team", "Oliver Bearman – Haas F1 Team", "Yuki Tsunoda – Red Bull Racing", "Isack Hadjar – Racing Bulls" }));

        txtPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPasswordActionPerformed(evt);
            }
        });

        lblPasswordConfirm.setText("Confirm Password");

        txtFullName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFullNameActionPerformed(evt);
            }
        });

        lblFullName.setText("Full Name");

        lblFavDriver.setText("Favourite Driver");

        btnRegister.setText("Register");
        btnRegister.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegisterActionPerformed(evt);
            }
        });

        lblPassword.setText("Password");

        lblEmail.setText("Email");

        lblUsername.setText("Username");

        javax.swing.GroupLayout pnlAllLayout = new javax.swing.GroupLayout(pnlAll);
        pnlAll.setLayout(pnlAllLayout);
        pnlAllLayout.setHorizontalGroup(
            pnlAllLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlAllLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlAllLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlAllLayout.createSequentialGroup()
                        .addGap(171, 171, 171)
                        .addComponent(btnRegister)
                        .addGap(133, 133, 133))
                    .addGroup(pnlAllLayout.createSequentialGroup()
                        .addGroup(pnlAllLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblFullName, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblUsername, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblPassword, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblPasswordConfirm, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblEmail, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblFavDriver, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(18, 18, 18)
                        .addGroup(pnlAllLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtFullName, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtUsername)
                            .addComponent(txtPassword)
                            .addComponent(txtPasswordConfirm)
                            .addComponent(txtEmail)
                            .addComponent(cmbFavDriver, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );

        pnlAllLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {cmbFavDriver, txtEmail, txtFullName, txtPassword, txtPasswordConfirm, txtUsername});

        pnlAllLayout.setVerticalGroup(
            pnlAllLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlAllLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlAllLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblFullName)
                    .addComponent(txtFullName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlAllLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblUsername)
                    .addComponent(txtUsername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlAllLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPassword)
                    .addComponent(txtPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlAllLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblPasswordConfirm)
                    .addComponent(txtPasswordConfirm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlAllLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblEmail)
                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlAllLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblFavDriver)
                    .addComponent(cmbFavDriver, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(btnRegister)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btnBackToLogIn)
                        .addGap(214, 214, 214))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(lblMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(225, 225, 225))))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(143, 143, 143)
                        .addComponent(pnlLogo2, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(52, 52, 52)
                        .addComponent(pnlAll, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(62, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addComponent(pnlLogo2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(pnlAll, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblMessage, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnBackToLogIn)
                .addGap(24, 24, 24))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPasswordActionPerformed

    private void txtFullNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFullNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFullNameActionPerformed

    private void txtUsernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUsernameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtUsernameActionPerformed

    private void btnBackToLogInActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackToLogInActionPerformed
        SignIn back = new SignIn();
        back.setVisible(true);
        this.setVisible(false);

    }//GEN-LAST:event_btnBackToLogInActionPerformed

    private void btnRegisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegisterActionPerformed
        if (txtFullName.getText().isEmpty() || txtUsername.getText().isEmpty()) {
            lblMessage.setText("Please fill all fields.");
            lblMessage.setForeground(java.awt.Color.RED);
            return;
        }
        String pass = txtPassword.getText();
        String confirm = txtPasswordConfirm.getText();
        if (!pass.equals(confirm)) {
            lblMessage.setText("Passwords do not match!");
            lblMessage.setForeground(java.awt.Color.RED);
            return;
        }
        if (FileHelper.usernameExists(txtUsername.getText().trim())) {
            javax.swing.JOptionPane.showMessageDialog(this,
                    "Username already taken!",
                    "Register Failed",
                    javax.swing.JOptionPane.ERROR_MESSAGE);
            return;
        }

        // ✅ Save to static variables FIRST
        savedFullName = txtFullName.getText();
        savedUsername = txtUsername.getText();
        savedPassword = pass;
        savedEmail = txtEmail.getText();
        savedDriver = cmbFavDriver.getSelectedItem().toString();

        // ✅ THEN save to file
        FileHelper.saveUser(savedFullName, savedUsername,
                savedPassword, savedEmail, savedDriver);

        // ✅ THEN go to MainMenu
        MainMenu menu = new MainMenu(savedUsername, true);
        menu.setVisible(true);
        this.dispose();    }//GEN-LAST:event_btnRegisterActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Register().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBackToLogIn;
    private javax.swing.JButton btnRegister;
    private javax.swing.JComboBox<String> cmbFavDriver;
    private javax.swing.JLabel lblEmail;
    private javax.swing.JLabel lblFavDriver;
    private javax.swing.JLabel lblFullName;
    private javax.swing.JLabel lblLogo;
    private javax.swing.JLabel lblLogo1;
    private javax.swing.JLabel lblLogo2;
    private javax.swing.JLabel lblLogoP;
    private javax.swing.JLabel lblLogoP1;
    private javax.swing.JLabel lblLogoP2;
    private javax.swing.JLabel lblMessage;
    private javax.swing.JLabel lblPassword;
    private javax.swing.JLabel lblPasswordConfirm;
    private javax.swing.JLabel lblUsername;
    private javax.swing.JPanel pnlAll;
    private javax.swing.JPanel pnlLogo;
    private javax.swing.JPanel pnlLogo1;
    private javax.swing.JPanel pnlLogo2;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtFullName;
    private javax.swing.JTextField txtPassword;
    private javax.swing.JTextField txtPasswordConfirm;
    private javax.swing.JTextField txtUsername;
    // End of variables declaration//GEN-END:variables
}
