
import java.io.*;

public class FileHelper {

    static String FILE = "users.txt";

    static {
        System.out.println("Saving to: " + new java.io.File(FILE).getAbsolutePath());
    }

    public static void saveUser(String fullName, String username,
            String password, String email, String driver) {
        try {
            FileWriter fw = new FileWriter(FILE, true); // true = append
            fw.write(fullName + "," + username + "," + password + ","
                    + email + "," + driver + "\n");
            fw.close();
        } catch (IOException e) {
            System.out.println("Error saving user: " + e.getMessage());
        }
    }

    public static boolean usernameExists(String username) {
        try {
            BufferedReader br = new BufferedReader(new FileReader(FILE));
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[1].equals(username)) {
                    br.close();
                    return true;
                }
            }
            br.close();
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
        return false;
    }

    public static String[] loginUser(String username, String password) {
        try {
            BufferedReader br = new BufferedReader(new FileReader(FILE));
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[1].equals(username) && parts[2].equals(password)) {
                    br.close();
                    return parts;
                }
            }
            br.close();
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
        return null;
    }

    public static void saveLastLogin(String username, String time) {
        try {
            java.io.FileWriter fw = new java.io.FileWriter(
                    System.getProperty("user.dir") + "/lastlogin_" + username + ".txt", false);
            fw.write(time);
            fw.close();
        } catch (java.io.IOException e) {
            System.out.println("Error saving login time: " + e.getMessage());
        }
    }

    public static String getLastLogin(String username) {
        try {
            java.io.BufferedReader br = new java.io.BufferedReader(
                    new java.io.FileReader(
                            System.getProperty("user.dir") + "/lastlogin_" + username + ".txt"));
            String time = br.readLine();
            br.close();
            return time != null ? time : "First login";
        } catch (java.io.IOException e) {
            return "First login";
        }
    }

    public static String[][] loadNews() {
        try {
            java.io.BufferedReader br = new java.io.BufferedReader(
                    new java.io.FileReader(
                            System.getProperty("user.dir") + "/news.txt"));
            java.util.ArrayList<String[]> list = new java.util.ArrayList<>();
            String line;
            while ((line = br.readLine()) != null) {
                list.add(line.split(","));
            }
            br.close();
            return list.toArray(new String[0][]);
        } catch (java.io.IOException e) {
            System.out.println("Could not load news: " + e.getMessage());
            return new String[0][];
        }
    }

    public static void saveScore(String username, int score) {
        try {
            java.io.FileWriter fw = new java.io.FileWriter(
                    System.getProperty("user.dir") + "/score_" + username + ".txt", false);
            fw.write(String.valueOf(score));
            fw.close();
        } catch (java.io.IOException e) {
            System.out.println("Error saving score: " + e.getMessage());
        }
    }

    public static java.util.ArrayList<String[]> loadLeaderboard() {
        java.util.ArrayList<String[]> board = new java.util.ArrayList<>();
        try {
            java.io.BufferedReader br = new java.io.BufferedReader(
                    new java.io.FileReader(
                            System.getProperty("user.dir") + "/users.txt"));
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) {
                    continue;
                }
                String[] parts = line.split(",");
                if (parts.length < 2) {
                    continue;
                }
                String username = parts[1].trim();
                int score = 0;
                try {
                    java.io.BufferedReader sr = new java.io.BufferedReader(
                            new java.io.FileReader(
                                    System.getProperty("user.dir") + "/score_" + username + ".txt"));
                    String s = sr.readLine();
                    sr.close();
                    if (s != null) {
                        score = Integer.parseInt(s.trim());
                    }
                } catch (Exception e) {
                    score = 0;
                }
                board.add(new String[]{parts[0].trim(), username, String.valueOf(score)});
            }
            br.close();
        } catch (java.io.IOException e) {
            System.out.println("Leaderboard error: " + e.getMessage());
        }
        board.sort((a, b) -> Integer.parseInt(b[2]) - Integer.parseInt(a[2]));
        return board;
    }

    public static int getLoginCount(String username) {
        try {
            java.io.BufferedReader br = new java.io.BufferedReader(
                    new java.io.FileReader(
                            System.getProperty("user.dir") + "/logins_" + username + ".txt"));
            int count = Integer.parseInt(br.readLine().trim());
            br.close();
            return count;
        } catch (Exception e) {
            return 1;
        }
    }

    public static void incrementLoginCount(String username) {
        int count = getLoginCount(username) + 1;
        try {
            java.io.FileWriter fw = new java.io.FileWriter(
                    System.getProperty("user.dir") + "/logins_" + username + ".txt", false);
            fw.write(String.valueOf(count));
            fw.close();
        } catch (Exception e) {
        }
    }

    public static String[] getNextRace() {
        try {
            java.io.BufferedReader br = new java.io.BufferedReader(
                    new java.io.FileReader(
                            System.getProperty("user.dir") + "/races.txt"));
            String line;
            java.time.LocalDate today = java.time.LocalDate.now();
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                java.time.LocalDate raceDate = java.time.LocalDate.parse(parts[3]);
                if (!raceDate.isBefore(today)) {
                    br.close();
                    return parts;
                }
            }
            br.close();
        } catch (java.io.IOException e) {
            System.out.println("Error reading races: " + e.getMessage());
        }
        return new String[]{"?", "Season Complete", "—", "—", "default.png"};
    }
}
