
import java.awt.Color;
import java.awt.Font;

public class Theme {

    public static final Color BG = new Color(10, 10, 15);
    public static final Color CARD = new Color(22, 22, 31);
    public static final Color BORDER = new Color(42, 42, 58);
    public static final Color ACCENT = new Color(225, 6, 0);
    public static final Color GOLD = new Color(255, 215, 0);
    public static final Color TEXT = new Color(240, 240, 240);
    public static final Color MUTED = new Color(136, 136, 136);
    public static final Color GREEN = new Color(0, 208, 132);
    public static final Color REDBULL = new Color(54, 113, 198);
    public static final Color FERRARI = new Color(220, 0, 0);
    public static final Color MERCEDES = new Color(0, 210, 190);
    public static final Color MCLAREN = new Color(255, 128, 0);

    public static final Font TITLE = new Font("Consolas", Font.BOLD, 28);
    public static final Font H1 = new Font("Consolas", Font.BOLD, 16);
    public static final Font H2 = new Font("Consolas", Font.BOLD, 12);
    public static final Font BODY = new Font("Consolas", Font.PLAIN, 12);
    public static final Font SMALL = new Font("Consolas", Font.PLAIN, 10);
    public static final Font MUTED_FONT = new Font("Consolas", Font.ITALIC, 10);

    public static void stylePanel(javax.swing.JPanel panel) {
        panel.setBackground(CARD);
        panel.setBorder(javax.swing.BorderFactory.createLineBorder(BORDER, 1));
    }

    // Style a normal label
    public static void styleLabel(javax.swing.JLabel label) {
        label.setForeground(new Color(238,222,197));
        label.setFont(BODY);
    }

    // Style a muted/header label
    public static void styleMuted(javax.swing.JLabel label) {
        label.setForeground(MUTED);
        label.setFont(SMALL);
    }

    // Style a red accent button
    public static void styleButton(javax.swing.JButton btn) {
        btn.setBackground(ACCENT);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Consolas", Font.BOLD, 12));
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setOpaque(false);
        btn.setForeground(MUTED);
    }

    public static void styleField(javax.swing.JTextField field) {
        field.setBackground(new Color(30, 30, 42));
        field.setForeground(TEXT);
        field.setFont(BODY);
        field.setCaretColor(TEXT);
        field.setBorder(javax.swing.BorderFactory.createLineBorder(BORDER));
    }

    public static void styleField(javax.swing.JPasswordField field) {
        field.setBackground(new Color(30, 30, 42));
        field.setForeground(TEXT);
        field.setCaretColor(TEXT);
        field.setBorder(javax.swing.BorderFactory.createLineBorder(BORDER));
    }
}
